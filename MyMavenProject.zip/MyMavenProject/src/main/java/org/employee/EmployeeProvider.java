package org.employee;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.MongoCollection;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.io.IOException;

import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.combine;
import static com.mongodb.client.model.Updates.set;

public class EmployeeProvider {

    private static ObjectMapper objectMapper;

    public EmployeeProvider() {
        this.objectMapper = new ObjectMapper();
    }

    //method to createEmployeeObject
    public Employee createEmployeeObject(int employeeID, String name, String address, int contactNumber, int pincode) {
        Employee employee = new Employee();
        employee.setEmployeeID(employeeID);
        employee.setName(name);
        employee.setAddress(address);
        employee.setContactNumber(contactNumber);
        employee.setPincode(pincode);
        return employee;
    }

    // New method to create an employee in the database
    public static Employee createEmployee(MongoCollection<Document> collection, Employee employee) throws JsonProcessingException {
        if (employee == null)
            throw new IllegalArgumentException("Employee object is null");
        Employee deserializedEmployee = null;
        // Serialize the employee to JSON
        Document doc = Document.parse(objectMapper.writeValueAsString(employee));
        collection.insertOne(doc);

        // Retrieve the document from the collection
        Document retrievedDoc = collection.find(eq("employeeID", employee.getEmployeeID())).first();
        if (retrievedDoc != null) {
            // Deserialize the JSON back to an employee object
            deserializedEmployee = objectMapper.readValue(retrievedDoc.toJson(), Employee.class);
            if (deserializedEmployee == null) {
                System.err.println("Failed to deserialize the employee.");
                return null;
            }
        } else
            System.err.println("No document found in the collection.");
        return deserializedEmployee;
    }


    // Method to update an employee in the database
    public static Employee updateEmployee(MongoCollection<Document> collection, Employee updatedEmployee) throws JsonProcessingException {
        if (updatedEmployee == null) {
            throw new IllegalArgumentException("Updated employee object is null");
        }

        // Create the update document
        Bson updateOperation = combine(set("name", updatedEmployee.getName()), set("address", updatedEmployee.getAddress()), set("contactNumber", updatedEmployee.getContactNumber()), set("pincode", updatedEmployee.getPincode()));

        // Update the employee in the collection
        long updateCount = collection.updateOne(eq("employeeID", updatedEmployee.getEmployeeID()), updateOperation).getModifiedCount();
        if (updateCount > 0) {
            System.out.println("Updated Employee with ID: " + updatedEmployee.getEmployeeID());
        } else {
            System.err.println("No employee found with ID: " + updatedEmployee.getEmployeeID() + " to update.");
        }

        Employee deserializedEmployee = null;
        Document retrievedDoc = collection.find(eq("employeeID", updatedEmployee.getEmployeeID())).first();
        if (updateCount > 0) {
            // Deserialize the JSON back to an employee object
            deserializedEmployee = objectMapper.readValue(retrievedDoc.toJson(), Employee.class);
            if (deserializedEmployee == null) {
                System.err.println("Failed to deserialize the employee.");
                return null;
            }
        }
        return deserializedEmployee;
    }

    public static Employee getEmployeeByID(MongoCollection<Document> collection, int employeeID) throws JsonProcessingException {
        Document retrievedDoc = collection.find(eq("employeeID", Main.employee.getEmployeeID())).first();
        Employee deserializedEmployee = null;
        if (retrievedDoc != null) {
            // Deserialize the JSON back to an employee object
            deserializedEmployee = objectMapper.readValue(retrievedDoc.toJson(), Employee.class);
            if (deserializedEmployee == null) {
                System.err.println("Failed to deserialize the employee.");
                return null;
            }
        } else
            System.err.println("No document found in the collection.");
        return deserializedEmployee;
    }

    public static boolean deleteEmployeeByID(MongoCollection<Document> collection, int employeeID) {
        long deleteCount = collection.deleteOne(eq("employeeID", employeeID)).getDeletedCount();
        if (deleteCount > 0) {
            System.out.println("Deleted Employee with ID: " + employeeID);
            return true;
        } else {
            System.err.println("No employee found with ID: " + employeeID + " to delete.");
            return false;
        }
    }

}


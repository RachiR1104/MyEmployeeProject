package org.employee;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.junit.jupiter.api.*;

import static com.mongodb.client.model.Filters.eq;
import static org.junit.jupiter.api.Assertions.*;

class EmployeeProviderTest {

    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> collection;

    @BeforeEach
    void setUp() {
        mongoClient = MongoClients.create("mongodb://localhost:27017");
        database = mongoClient.getDatabase("employeeDB");
        collection = database.getCollection("employees");
//        collection.drop(); // Clear the collection before each test
    }

    @AfterEach
    void tearDown() {
        if (mongoClient != null) {
            mongoClient.close();
        }
    }

    @Test
    void testCreateEmployee() throws JsonProcessingException {
        EmployeeProvider employeeProvider = new EmployeeProvider();
        Employee employee = employeeProvider.createEmployeeObject(1, "John Doe", "123 Main St", 1234567890, 12345);

        Employee createdEmployee = EmployeeProvider.createEmployee(collection, employee);

        assertNotNull(createdEmployee, "The created employee should not be null.");
        assertEquals(employee.getEmployeeID(), createdEmployee.getEmployeeID(), "Employee ID should match.");
        assertEquals(employee.getName(), createdEmployee.getName(), "Employee name should match.");
        assertEquals(employee.getAddress(), createdEmployee.getAddress(), "Employee address should match.");
        assertEquals(employee.getContactNumber(), createdEmployee.getContactNumber(), "Employee contact number should match.");
        assertEquals(employee.getPincode(), createdEmployee.getPincode(), "Employee pincode should match.");
    }

    @Test
    void testUpdateEmployee() throws JsonProcessingException {
        EmployeeProvider employeeProvider = new EmployeeProvider();
        Employee employee = employeeProvider.createEmployeeObject(1, "John Doe", "123 Main St UPDATEDDD", 535555555, 6464664);

        Employee createdEmployee = EmployeeProvider.updateEmployee(collection, employee);

        assertNotNull(createdEmployee, "The created employee should not be null.");
        assertEquals(employee.getEmployeeID(), createdEmployee.getEmployeeID(), "Employee ID should match.");
        assertEquals(employee.getName(), createdEmployee.getName(), "Employee name should match.");
        assertEquals(employee.getAddress(), createdEmployee.getAddress(), "Employee address should match.");
        assertEquals(employee.getContactNumber(), createdEmployee.getContactNumber(), "Employee contact number should match.");
        assertEquals(employee.getPincode(), createdEmployee.getPincode(), "Employee pincode should match.");
    }

    @Test
    void testGetEmployeeByID() throws JsonProcessingException {
        EmployeeProvider employeeProvider = new EmployeeProvider();
        Employee employee = employeeProvider.createEmployeeObject(1, "John Doe", "123 Main St UPDATEDDD", 535555555, 6464664);

        // Create the employee in the database
        Employee createdEmployee = EmployeeProvider.createEmployee(collection, employee);

        // Retrieve the employee by ID
        Employee retrievedEmployee = EmployeeProvider.getEmployeeByID(collection, createdEmployee.getEmployeeID());

        assertNotNull(retrievedEmployee, "The retrieved employee should not be null.");
        assertEquals(createdEmployee.getEmployeeID(), retrievedEmployee.getEmployeeID(), "Employee ID should match.");
        assertEquals(createdEmployee.getName(), retrievedEmployee.getName(), "Employee name should match.");
        assertEquals(createdEmployee.getAddress(), retrievedEmployee.getAddress(), "Employee address should match.");
        assertEquals(createdEmployee.getContactNumber(), retrievedEmployee.getContactNumber(), "Employee contact number should match.");
        assertEquals(createdEmployee.getPincode(), retrievedEmployee.getPincode(), "Employee pincode should match.");
    }

    @Test
    void testDeleteEmployeeByID() throws JsonProcessingException {
        EmployeeProvider employeeProvider = new EmployeeProvider();
        Employee employee = employeeProvider.createEmployeeObject(1, "John Doe", "123 Main St UPDATEDDD", 535555555, 6464664);

        // Create the employee in the database
        Employee createdEmployee = EmployeeProvider.createEmployee(collection, employee);

        assertNotNull(createdEmployee, "The created employee should not be null.");
        assertEquals(employee.getEmployeeID(), createdEmployee.getEmployeeID(), "Employee ID should match.");

        // Delete the employee by ID
        boolean isDeleted = EmployeeProvider.deleteEmployeeByID(collection, createdEmployee.getEmployeeID());
        assertTrue(isDeleted, "The employee should be deleted successfully.");

        // Verify the employee is deleted
        Document retrievedDoc = collection.find(eq("employeeID", createdEmployee.getEmployeeID())).first();
        assertNull(retrievedDoc, "The retrieved document should be null after deletion.");
    }

}